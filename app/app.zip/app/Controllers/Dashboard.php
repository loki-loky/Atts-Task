<?php

namespace App\Controllers;

use App\Models\ProductModel;
use App\Models\CategoryModel;

class Dashboard extends BaseController
{
    protected $productModel;
    protected $categoryModel;

    public function __construct()
    {
        $this->productModel = new ProductModel();
        $this->categoryModel = new CategoryModel();
    }

    public function index()
    {
        $data = [
            'total_products' => $this->productModel->countAll(),
            'total_categories' => $this->categoryModel->countAll(),
            'recent_products' => $this->productModel->orderBy('created_at', 'DESC')->limit(5)->findAll()
        ];

        return view('dashboard/index', $data);
    }
} 