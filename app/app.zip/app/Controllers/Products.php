<?php

namespace App\Controllers;

use App\Models\ProductModel;
use App\Models\CategoryModel;

class Products extends BaseController
{
    protected $productModel;
    protected $categoryModel;

    public function __construct()
    {
        $this->productModel = new ProductModel();
        $this->categoryModel = new CategoryModel();
    }

    public function index()
    {
        return view('products/index', [
            'categories' => $this->categoryModel->findAll()
        ]);
    }

    public function getProducts()
    {
        $draw = $this->request->getGet('draw');
        $start = $this->request->getGet('start');
        $length = $this->request->getGet('length');
        $search = $this->request->getGet('search')['value'];
        $order = $this->request->getGet('order')[0];

        $total = $this->productModel->getTotalProducts($search);
        $products = $this->productModel->getProductsWithCategory($length, $start, $search, $order);

        $data = [];
        foreach ($products as $product) {
            $data[] = [
                'id' => $product['id'],
                'name' => $product['name'],
                'category' => $product['category_name'],
                'price' => number_format($product['price'], 2),
                'image' => $product['image'] ? '<img src="' . base_url('uploads/' . $product['image']) . '" width="50">' : 'No Image',
                'actions' => '<button class="btn btn-sm btn-primary edit-product" data-id="' . $product['id'] . '">Edit</button> ' .
                           '<button class="btn btn-sm btn-danger delete-product" data-id="' . $product['id'] . '">Delete</button>'
            ];
        }

        return $this->response->setJSON([
            'draw' => $draw,
            'recordsTotal' => $total,
            'recordsFiltered' => $total,
            'data' => $data
        ]);
    }

    public function create()
    {
        if (!$this->validate($this->productModel->validationRules)) {
            return $this->response->setJSON([
                'status' => 'error',
                'errors' => $this->validator->getErrors()
            ]);
        }

        $data = $this->request->getPost();
        $data['slug'] = $this->productModel->createSlug($data['name']);

        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image && $image->isValid() && !$image->hasMoved()) {
            $newName = $image->getRandomName();
            $image->move(WRITEPATH . 'uploads', $newName);

            // Resize image
            $image = \Config\Services::image()
                ->withFile(WRITEPATH . 'uploads/' . $newName)
                ->resize(500, 500, true, 'height')
                ->save(WRITEPATH . 'uploads/' . $newName);

            $data['image'] = $newName;
        }

        $this->productModel->insert($data);

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Product created successfully'
        ]);
    }

    public function edit($id)
    {
        $product = $this->productModel->find($id);
        if (!$product) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Product not found'
            ]);
        }

        return $this->response->setJSON([
            'status' => 'success',
            'data' => $product
        ]);
    }

    public function update($id)
    {
        if (!$this->validate($this->productModel->validationRules)) {
            return $this->response->setJSON([
                'status' => 'error',
                'errors' => $this->validator->getErrors()
            ]);
        }

        $data = $this->request->getPost();
        $data['slug'] = $this->productModel->createSlug($data['name']);

        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image && $image->isValid() && !$image->hasMoved()) {
            $newName = $image->getRandomName();
            $image->move(WRITEPATH . 'uploads', $newName);

            // Resize image
            $image = \Config\Services::image()
                ->withFile(WRITEPATH . 'uploads/' . $newName)
                ->resize(500, 500, true, 'height')
                ->save(WRITEPATH . 'uploads/' . $newName);

            // Delete old image
            $oldProduct = $this->productModel->find($id);
            if ($oldProduct && $oldProduct['image']) {
                @unlink(WRITEPATH . 'uploads/' . $oldProduct['image']);
            }

            $data['image'] = $newName;
        }

        $this->productModel->update($id, $data);

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Product updated successfully'
        ]);
    }

    public function delete($id)
    {
        $product = $this->productModel->find($id);
        if (!$product) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Product not found'
            ]);
        }

        // Delete image
        if ($product['image']) {
            @unlink(WRITEPATH . 'uploads/' . $product['image']);
        }

        $this->productModel->delete($id);

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Product deleted successfully'
        ]);
    }
} 