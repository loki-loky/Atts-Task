<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Products Management</h1>
    
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div>
                <i class="fas fa-table me-1"></i>
                Products List
            </div>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#productModal">
                Add New Product
            </button>
        </div>
        <div class="card-body">
            <table id="productsTable" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Image</th>
                        <th>Actions</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>

<!-- Product Modal -->
<div class="modal fade" id="productModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add/Edit Product</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="productForm" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="id" id="product_id">
                    
                    <div class="mb-3">
                        <label for="name" class="form-label">Product Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>

                    <div class="mb-3">
                        <label for="category_id" class="form-label">Category</label>
                        <select class="form-select" id="category_id" name="category_id" required>
                            <option value="">Select Category</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?= $category['id'] ?>"><?= $category['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="price" class="form-label">Price</label>
                        <input type="number" class="form-control" id="price" name="price" step="0.01" required>
                    </div>

                    <div class="mb-3">
                        <label for="image" class="form-label">Product Image</label>
                        <input type="file" class="form-control" id="image" name="image" accept="image/*">
                        <div id="imagePreview" class="mt-2"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Product</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?= $this->section('scripts') ?>
<script>
$(document).ready(function() {
    var table = $('#productsTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: '<?= base_url('products/getProducts') ?>',
        columns: [
            { data: 'id' },
            { data: 'name' },
            { data: 'category' },
            { data: 'price' },
            { data: 'image' },
            { data: 'actions' }
        ],
        order: [[0, 'desc']],
        pageLength: 10,
        lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
        columnDefs: [
            { targets: [0], visible: false },
            { targets: [5], orderable: false }
        ]
    });

    // Handle form submission
    $('#productForm').on('submit', function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        var id = $('#product_id').val();
        var url = id ? '<?= base_url('products/update/') ?>' + id : '<?= base_url('products/create') ?>';

        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.status === 'success') {
                    $('#productModal').modal('hide');
                    table.ajax.reload();
                    toastr.success(response.message);
                } else {
                    toastr.error(response.message);
                }
            },
            error: function() {
                toastr.error('An error occurred');
            }
        });
    });

    // Handle edit button click
    $(document).on('click', '.edit-product', function() {
        var id = $(this).data('id');
        $.get('<?= base_url('products/edit/') ?>' + id, function(response) {
            if (response.status === 'success') {
                var product = response.data;
                $('#product_id').val(product.id);
                $('#name').val(product.name);
                $('#category_id').val(product.category_id);
                $('#description').val(product.description);
                $('#price').val(product.price);
                if (product.image) {
                    $('#imagePreview').html('<img src="<?= base_url('uploads/') ?>' + product.image + '" width="100">');
                }
                $('#productModal').modal('show');
            }
        });
    });

    // Handle delete button click
    $(document).on('click', '.delete-product', function() {
        var id = $(this).data('id');
        if (confirm('Are you sure you want to delete this product?')) {
            $.post('<?= base_url('products/delete/') ?>' + id, function(response) {
                if (response.status === 'success') {
                    table.ajax.reload();
                    toastr.success(response.message);
                } else {
                    toastr.error(response.message);
                }
            });
        }
    });

    // Reset form when modal is closed
    $('#productModal').on('hidden.bs.modal', function() {
        $('#productForm')[0].reset();
        $('#product_id').val('');
        $('#imagePreview').html('');
    });

    // Image preview
    $('#image').on('change', function() {
        var file = this.files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#imagePreview').html('<img src="' + e.target.result + '" width="100">');
            }
            reader.readAsDataURL(file);
        }
    });
});
</script>
<?= $this->endSection() ?>

<?= $this->endSection() ?> 