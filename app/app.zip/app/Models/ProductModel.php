<?php

namespace App\Models;

use CodeIgniter\Model;

class ProductModel extends Model
{
    protected $table = 'products';
    protected $primaryKey = 'id';
    protected $allowedFields = ['category_id', 'name', 'slug', 'description', 'price', 'image'];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    protected $validationRules = [
        'category_id' => 'required|numeric',
        'name' => 'required|min_length[3]',
        'slug' => 'required|is_unique[products.slug,id,{id}]',
        'price' => 'required|numeric',
        'image' => 'permit_empty|uploaded[image]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/png]|max_size[image,2048]'
    ];

    public function getProductsWithCategory($limit = 10, $offset = 0, $search = '', $order = [])
    {
        $builder = $this->select('products.*, categories.name as category_name')
            ->join('categories', 'categories.id = products.category_id');

        if (!empty($search)) {
            $builder->groupStart()
                ->like('products.name', $search)
                ->orLike('products.description', $search)
                ->orLike('categories.name', $search)
                ->groupEnd();
        }

        if (!empty($order)) {
            $builder->orderBy($order['column'], $order['dir']);
        }

        return $builder->limit($limit, $offset)->findAll();
    }

    public function getTotalProducts($search = '')
    {
        $builder = $this->select('products.*, categories.name as category_name')
            ->join('categories', 'categories.id = products.category_id');

        if (!empty($search)) {
            $builder->groupStart()
                ->like('products.name', $search)
                ->orLike('products.description', $search)
                ->orLike('categories.name', $search)
                ->groupEnd();
        }

        return $builder->countAllResults();
    }

    public function createSlug($name)
    {
        $slug = url_title($name, '-', true);
        $count = $this->where('slug', $slug)->countAllResults();
        
        if ($count > 0) {
            $slug = $slug . '-' . ($count + 1);
        }
        
        return $slug;
    }
} 